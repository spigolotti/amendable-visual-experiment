# input_handler.py

def handle_user_input(pygame):
    current_decision = None
    decision_time = None
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        current_decision = -1
        decision_time = pygame.time.get_ticks()
    elif keys[pygame.K_RIGHT]:
        current_decision = 1
        decision_time = pygame.time.get_ticks()
    return current_decision, decision_time
