import random

def update_dot(dot, screen_width, q):
	if random.random() <= q:
		dot['x'] += 1  # With probability q, add +1
	else:
		dot['x'] += -1  # With probability 1-q, add -1
	if random.random() <= 0.5:
		dot['y'] += 1
	else: 
		dot['y'] += -1
	
	# Keep dots within the screen bounds
	dot['x'] = (dot['x']+screen_width)%screen_width
	dot['y'] = (dot['y']+screen_width)%screen_width
