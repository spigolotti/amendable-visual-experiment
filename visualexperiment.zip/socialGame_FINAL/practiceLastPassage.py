import pygame
import sys
from game_round import run_total_last_passage
from game_round import run_total_last_passage_practice1
from game_round import run_total_last_passage_practice2
import csv
from drawing_utils import show_initial_screen
import os
from datetime import datetime

# Initialize Pygame
pygame.init()

# Screen dimensions
screen_width, screen_height = 1400, 800
screen = pygame.display.set_mode((screen_width, screen_height), pygame.FULLSCREEN)

# Game clock
clock = pygame.time.Clock()

# Run the game for a specified number of repetitions and collect decision times
num_repetitions = 30

game_duration=10000 #in milliseconds
pi0 = 0.5 #proability that hypothesis is +

now = datetime.now()

# Format the date and time as a string
folder_name = now.strftime("%Y-%m-%d_%H-%M-%S")

data_folder_path = 'data'

full_folder_path = os.path.join(data_folder_path, folder_name)

# Create the folder
os.makedirs(full_folder_path)

#last passage game 3 
qP = 0.57 #probability to move right under hypothesis H=+
qM = 0.43 #probability to  move right under hypothesis H=-
gameID = "LPP"
run_total_last_passage_practice2(screen, screen_width, screen_height, clock, game_duration, qP, qM, pi0, num_repetitions, gameID, full_folder_path, 3)

pygame.quit()
