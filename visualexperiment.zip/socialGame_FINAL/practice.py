import pygame
import sys
import os
from datetime import datetime
from game_round import run_total_last_passage
from game_round import run_total_last_passage_practice
from game_round import run_total_first_passage
from game_round import run_total_first_passage_practice

# Initialize Pygame
pygame.init()

# Set up display in full-screen mode
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)  # Fullscreen
screen_width, screen_height = screen.get_size()
pygame.display.set_caption("Game Hub")

# Define colors
white = (255, 255, 255)
black = (0, 0, 0)
button_color = (100, 200, 100)
button_hover_color = (150, 250, 150)

# Define font
font = pygame.font.Font(None, 36)

# Define game states
MAIN_MENU = "main_menu"
GAME_1 = "Game1"
GAME_2 = "Game2"
GAME_3 = "Game3"
GAME_4 = "Game4"
current_state = MAIN_MENU

# Button class
class Button:
	def __init__(self, text, pos, callback):
		self.text = text
		self.pos = pos
		self.callback = callback
		self.rect = pygame.Rect(pos[0], pos[1], 450, 50)

	def draw(self, surface):
		# Change color on hover
		color = button_hover_color if self.rect.collidepoint(pygame.mouse.get_pos()) else button_color
		pygame.draw.rect(surface, color, self.rect)

		# Draw text
		text_surface = font.render(self.text, True, black)
		text_rect = text_surface.get_rect(center=self.rect.center)
		surface.blit(text_surface, text_rect)

	def handle_event(self, event):
		if event.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(event.pos):
			self.callback()

# Callback functions to change game states
def start_game_1():
	global current_state
	current_state = GAME_1

def start_game_2():
	global current_state
	current_state = GAME_2


def start_game_3():
	global current_state
	current_state = GAME_3

def start_game_4():
	global current_state
	current_state = GAME_4



# Create buttons for the main menu
buttons = [
	Button("Irrevocable decisions with aid", (screen_width // 2 - 225, 200), start_game_1),
	Button("Irrevocable decisions without aid", (screen_width // 2 - 225, 300), start_game_2),
	Button("Amendable decisions with aid", (screen_width // 2 - 225, 400), start_game_3),
	Button("Amendable decisions without aid", (screen_width // 2 - 225, 500), start_game_4)
]

# Main menu loop
def main_menu():
	screen.fill(white)
	for button in buttons:
		button.draw(screen)
	pygame.display.flip()



def game_4(screen, screen_width, screen_height):

	clock = pygame.time.Clock()
	game_duration = 10000  # in milliseconds
	pi0 = 0.5  # probability that hypothesis is +
    
	# Create a unique folder for game data
	now = datetime.now()
    
	# Game-specific parameters
	qP = 0.57  # probability to move right under hypothesis H=+
	qM = 0.43  # probability to move right under hypothesis H=-
    
	# Run the game with the parameters
	run_total_last_passage_practice(
	screen, screen_width, screen_height, clock, game_duration,qP, qM, pi0, 0)
    
	# After the game ends, return to the main menu
	global current_state
	current_state = MAIN_MENU





def game_3(screen, screen_width, screen_height):

	clock = pygame.time.Clock()
	game_duration = 10000  # in milliseconds
	pi0 = 0.5  # probability that hypothesis is +
    
	# Create a unique folder for game data
	now = datetime.now()
    
	# Game-specific parameters
	qP = 0.57  # probability to move right under hypothesis H=+
	qM = 0.43  # probability to move right under hypothesis H=-
    
	# Run the game with the parameters
	run_total_last_passage_practice(
	screen, screen_width, screen_height, clock, game_duration,qP, qM, pi0, 1)
    
	# After the game ends, return to the main menu
	global current_state
	current_state = MAIN_MENU





# Placeholder for Game 2 logic
def game_2(screen, screen_width, screen_height):

	clock = pygame.time.Clock()
	pi0 = 0.5  # probability that hypothesis is +
    
	# Create a unique folder for game data
	now = datetime.now()
    
	# Game-specific parameters
	qP = 0.57  # probability to move right under hypothesis H=+
	qM = 0.43  # probability to move right under hypothesis H=-
    
	# Run the game with the parameters
	run_total_first_passage_practice(
	screen, screen_width, screen_height, clock,qP, qM, pi0,0)
    
	# After the game ends, return to the main menu
	global current_state
	current_state = MAIN_MENU


def game_1(screen, screen_width, screen_height):
	clock = pygame.time.Clock()
	pi0 = 0.5  # probability that hypothesis is +
    
	# Create a unique folder for game data
	now = datetime.now()
    
	# Game-specific parameters
	qP = 0.57  # probability to move right under hypothesis H=+
	qM = 0.43  # probability to move right under hypothesis H=-
    
	# Run the game with the parameters
	run_total_first_passage_practice(
	screen, screen_width, screen_height, clock, qP, qM, pi0, 1)
    
	# After the game ends, return to the main menu
	global current_state
	current_state = MAIN_MENU


# Helper function to draw centered text
def draw_text(surface, text, position, font_size, color):
	font = pygame.font.Font(None, font_size)
	text_surface = font.render(text, True, color)
	text_rect = text_surface.get_rect(center=position)
	surface.blit(text_surface, text_rect)

# Main game loop
running = True
while running:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			running = False
		elif event.type == pygame.KEYDOWN:
			if event.key == pygame.K_ESCAPE:
				running = False  # Exit the game on Escape key
			elif event.key == pygame.K_RETURN and current_state != MAIN_MENU:
				current_state = MAIN_MENU  # Return to the main menu on Enter key

		# Main menu interactions
		if current_state == MAIN_MENU:
			for button in buttons:
				button.handle_event(event)

	# Display the current state screen	
	if current_state == MAIN_MENU:
		main_menu()
	elif current_state == GAME_1:
		game_1(screen, screen_width, screen_height)  # Start Game 1 with the function below
	elif current_state == GAME_2:
		game_2(screen, screen_width, screen_height)  # Start Game 2 with the function below
	elif current_state == GAME_3:
		game_3(screen, screen_width, screen_height)  # Start Game 3 with the function below
	elif current_state == GAME_4:
		game_4(screen, screen_width, screen_height)  # Start Game 4 with the function below


# Quit pygame
pygame.quit()
sys.exit()
