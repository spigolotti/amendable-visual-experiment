import pygame
import sys
from game_round import run_first_passage_game
import csv
from drawing_utils import show_initial_screen

# Initialize Pygame
pygame.init()

# Screen dimensions
screen_width, screen_height = 1400, 800
screen = pygame.display.set_mode((screen_width, screen_height))


pygame.display.set_caption("Irrevocable Decision Game")
textDisplay = "Irrevocable Decision Game"

# Game clock
clock = pygame.time.Clock()

show_initial_screen(screen, screen_width, screen_height, textDisplay)


# Run the game for a specified number of repetitions and collect decision times
num_repetitions = 100. ## IS THIS USED? 
decision_records = []

game_duration=10000 #in milliseconds
qP = 0.53 #probability to move right under hypothesis H=+. ## SAME, IS THIS USED?
qM = 0.47 #probability to  move right under hypothesis H=-
pi0 = 0.5 #proability that hypothesis is +

for j in range(num_repetitions):
	run_first_passage_game(screen, clock, decision_records, game_duration, qP, qM, pi0, j)

pygame.quit()


with open('data/first_passage.csv', 'w', newline='') as file:
	writer = csv.writer(file)
	writer.writerow(['Decision Time (ms)', 'Correct?'])  # Writing header
	for record in decision_records:
	# Convert boolean to a more readable format ("Yes" or "No")
		correctness = "Yes" if record[1] else "No"
		writer.writerow([record[0], correctness])


