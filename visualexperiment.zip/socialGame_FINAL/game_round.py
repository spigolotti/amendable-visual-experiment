import pygame
import sys
import csv
from drawing_utils import show_initial_screen,show_initial_screen_practice
import os
import random
import numpy as np
from input_handler import handle_user_input
from dot_motion import update_dot
from drawing_utils import draw_text, draw_dot, show_end_message, draw_dashed_vertical_line, show_end_message_practice, show_end_message_practicev2  # Import the new drawing functions


def run_last_passage_game(screen, clock, decision_records, finalDecision_List, finalDecisionTime_List, correctDecision_List, optimalDecision_List, optimalDecisionTime_List, trajectories_List, optimalDecision_records, game_duration, qP,qM, pi0, gameNumber):
	screen_width, screen_height = screen.get_size()
	black = (0, 0, 0)
	white = (255, 255, 255)
	color_amend = (33, 158, 188)
	color_irr = (251, 133, 0)
	green = (34, 139, 34)  # Forest green
	red = (220, 20, 60)    # Crimson red

	cohBias = np.exp(pi0)/(1+np.exp(pi0))

	H = np.random.choice([-1, 1], p=[cohBias, 1-cohBias])
	#"-1" corresponds to Left and "+1" corresponds to right
	

	if H==1:
		q = qP
	else: 
		q = qM

	correct_decision = (int)(H)
	correctDecision_List.append(correct_decision)
	
	dot = {'x': screen_width/2, 'y': screen_height/2}

	start_time = pygame.time.get_ticks()

	running = True

	if pi0>0.5: 
		current_decision = -1
	elif pi0<0.5: 
		current_decision = 1
	else:
		current_decision = -1 if np.random.choice([-1,1]) == 1 else 1

	decision_time = 0

	all_decisions = []  #list that stores all decisions and decsion times
	all_optimalDecisions = []
	
	all_decisions.append((0,current_decision))
	all_optimalDecisions.append((0,current_decision))
	
	optimalDecision = current_decision
	optimalDecisionTime = 0
	initialDotX =  dot['x']
	trajectory = []

	while running:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				exit()
			elif event.type == pygame.KEYDOWN:
				if event.key == pygame.K_ESCAPE:
					screen_width, screen_height = 800, 600
					screen = pygame.display.set_mode((screen_width, screen_height))
					#pygame.quit()
					#sys.exit()

		screen.fill(white)
		update_dot(dot, screen_width, q)
		draw_dot(screen, dot, black)  
		trajectory.append((dot['x'], dot['y']))

		if dot['x']-initialDotX>0: 
			if optimalDecision == -1:
				optimalDecisionTime = pygame.time.get_ticks() - start_time
				all_optimalDecisions.append((optimalDecisionTime,1))
			optimalDecision = 1
		else:
			if optimalDecision == 1:
				optimalDecisionTime = pygame.time.get_ticks() - start_time
				all_optimalDecisions.append((optimalDecisionTime,-1))
			optimalDecision = -1

		decisionT, time = handle_user_input(pygame)
		if time is not None:
			all_decisions.append((time-start_time,decisionT))
			if current_decision != decisionT:
				current_decision = decisionT
				decision_time = time - start_time

		# Display useful info:
		if current_decision==1:
			dec_text='right'
		else:
			dec_text='left'
		draw_text(screen, f"Amendable decisions game", (50, 50), 30, color_amend)
		draw_text(screen, f"Amount of games played: {gameNumber}", (50, 90), 30, black)
		draw_text(screen, f"Decision: {dec_text}", (50, 120), 30, black)
		draw_text(screen, f"Time: {decision_time}ms", (50, 150), 30, black)

		pygame.display.flip()
		clock.tick(60)
		#this corresponds with 60 fps

		if pygame.time.get_ticks() - start_time > game_duration:
			running = False



	decision_records.append(all_decisions)
	optimalDecision_records.append(all_optimalDecisions)
	finalDecision_List.append(current_decision)
	finalDecisionTime_List.append(decision_time)
	optimalDecision_List.append(optimalDecision)
	optimalDecisionTime_List.append(optimalDecisionTime)
	trajectories_List.append(trajectory)

	# Ensure decision_times is not empty to avoid division by zero and other errors
	if len(finalDecisionTime_List):
		average_decision_time = round(sum(finalDecisionTime_List) / len(finalDecisionTime_List),0)
		worst_decision_time = max(finalDecisionTime_List)
		best_decision_time = min(finalDecisionTime_List)
	else:
		average_decision_time = 0
		worst_decision_time = 0
		best_decision_time = 0


	if current_decision == correct_decision:
		message1 = f"Correct decision!"
		message2 = f"Final time: {decision_time}ms"
		show_end_message_practice(screen, message1, message2, green,  white, average_decision_time)
	else : 
		message1 = f"Wrong decision! \n Please try to be more accurate"
		message2 = f"Final time: {decision_time}ms"
		show_end_message_practice(screen, message1, message2, red, white, average_decision_time)



	#if current_decision == correct_decision:
#		message1 = f"Correct decision!"#
#		message2 = f"Final time: {decision_time}ms"
#		show_end_message_practice(screen, message1, message2, green,  white, average_decision_time)
#	else : 
#		message1 = f"Wrong decision!"
#		message2 = f"Please try to be more accurate."
#		show_end_message_practice(screen, message1, message2, red, white, average_decision_time)





def run_last_passage_game_practice(screen, clock, game_duration, qP,qM, pi0, gameNumber, averageDecision, bestDecision, worseDecision, aid):
	screen_width, screen_height = screen.get_size()
	black = (0, 0, 0)
	white = (255, 255, 255)
	color_amend = (33, 158, 188)
	color_irr = (251, 133, 0)
	green = (34, 139, 34)  # Forest green
	red = (220, 20, 60)    # Crimson red

	cohBias = np.exp(pi0)/(1+np.exp(pi0))

	H = np.random.choice([-1, 1], p=[cohBias, 1-cohBias])
	#"-1" corresponds to Left and "+1" corresponds to right
		

	if H==1:
		q = qP
	else: 
		q = qM

	correct_decision = (int)(H)
	
	dot = {'x': screen_width/2, 'y': screen_height/2}

	start_time = pygame.time.get_ticks()

	running = True
	pushQ = False

	if pi0>0.5: 
		current_decision = -1
	elif pi0<0.5: 
		current_decision = 1
	else:
		current_decision = -1 if np.random.choice([-1,1]) == 1 else 1

	decision_time = 0

	all_decisions = []  #list that stores all decisions and decsion times
	all_optimalDecisions = []
	
	all_decisions.append((0,current_decision))
	all_optimalDecisions.append((0,current_decision))
	
	optimalDecision = current_decision
	optimalDecisionTime = 0
	initialDotX =  dot['x']

	while running:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				exit()
			elif event.type == pygame.KEYDOWN:
				if event.key == pygame.K_ESCAPE:
					screen_width, screen_height = 800, 600
					screen = pygame.display.set_mode((screen_width, screen_height))
				elif event.key == pygame.K_q:
					running = False
					pushQ = True
					return pushQ
					#pygame.quit()
					#sys.exit()

		screen.fill(white)
		update_dot(dot, screen_width, q)
		draw_dot(screen, dot, black)  
		if aid == 1:
			draw_dashed_vertical_line(screen, black, thickness=2, dash_length=10, gap_length=10)

		if dot['x']-initialDotX>0: 
			if optimalDecision == -1:
				optimalDecisionTime = pygame.time.get_ticks() - start_time
				all_optimalDecisions.append((optimalDecisionTime,1))
			optimalDecision = 1
		else:
			if optimalDecision == 1:
				optimalDecisionTime = pygame.time.get_ticks() - start_time
				all_optimalDecisions.append((optimalDecisionTime,-1))
			optimalDecision = -1

		decisionT, time = handle_user_input(pygame)
		if time is not None:
			all_decisions.append((time-start_time,decisionT))
			if current_decision != decisionT:
				current_decision = decisionT
				decision_time = time - start_time

		# Display useful info:
		if current_decision==1:
			dec_text='right'
		else:
			dec_text='left'

		if aid == 1:
			draw_text(screen, f"Amendable decisions game: with aid", (50, 50), 30, color_amend)
		else:
			draw_text(screen, f"Amendable decisions game: without aid", (50, 50), 30, color_amend)			

		draw_text(screen, f"Amount of games played: {gameNumber}", (50, 90), 30, black)
		draw_text(screen, f"Decision: {dec_text}", (50, 120), 30, black)
		draw_text(screen, f"Time: {decision_time}ms", (50, 150), 30, black)
		draw_text(screen, f"Push the q button to exit", (50, screen_height-50), 30, black)

		pygame.display.flip()
		clock.tick(60)
		#this corresponds with 60 fps

		if pygame.time.get_ticks() - start_time > game_duration:
			running = False



	averageDecisionTime = (gameNumber*averageDecision+decision_time)/(gameNumber+1)


	if current_decision == correct_decision:
		message1 = f"Correct decision!"
		message2 = f"Final time: {decision_time}ms"
		show_end_message_practice(screen, message1, message2, green,  white, averageDecisionTime)
	else : 
		message1 = f"Wrong decision! \n Please try to be more accurate"
		message2 = f"Final time: {decision_time}ms"
		show_end_message_practice(screen, message1, message2, red, white, averageDecisionTime)




def run_total_last_passage(screen, screen_width, screen_height, clock, game_duration, qP, qM, pi0, num_repetitions, game_ID, full_folder_path, game_counter):

	decision_records = []
	finalDecision_List = []
	finalDecisionTime_List = []
	correctDecision_List = []
	trajectories_List = []

	optimalDecision_List = []
	optimalDecisionTime_List = []
	optimalDecision_records = []

	# Variables to track performance
	correct_games = 0
	total_decision_time = 0

	pygame.display.set_caption("Amendable Decisions Game")
	textDisplay = f"Amendable Decisions Game {game_counter}"
	show_initial_screen(screen, screen_width, screen_height, textDisplay, 1)

	for j in range(num_repetitions):
		run_last_passage_game(screen, clock, decision_records, finalDecision_List, finalDecisionTime_List, correctDecision_List, optimalDecision_List, optimalDecisionTime_List, trajectories_List, optimalDecision_records, game_duration, qP, qM, pi0, j)


	#display_summary(screen, num_repetitions, fraction_correct, average_decision_time)

	# Define file paths
	decision_times_path = os.path.join(full_folder_path, f'{game_ID}_final_decision_times.txt')
	decisions_made_path = os.path.join(full_folder_path, f'{game_ID}_final_decisions.txt')
	correct_decisions_path = os.path.join(full_folder_path, f'{game_ID}_correct_decisions.txt')
	full_decisions_path = os.path.join(full_folder_path, f'{game_ID}_full_decision_sequence.txt')
	full_Optimaldecisions_path = os.path.join(full_folder_path, f'{game_ID}_full_optimal_decision_sequence.txt')
	optimal_decisions_path = os.path.join(full_folder_path, f'{game_ID}_optimal_decisions.txt')
	optimal_times_path = os.path.join(full_folder_path, f'{game_ID}_optimal_decision_times.txt')
	trajectories_path = os.path.join(full_folder_path, f'{game_ID}_trajectories.txt')


	# Write event times to the file
	with open(decision_times_path, 'w') as file:
		for finalD in finalDecisionTime_List:
        		file.write(f"{finalD}\n")


	# Write event times to the file
	with open(optimal_times_path, 'w') as file:
		for finalD in optimalDecisionTime_List:
        		file.write(f"{finalD}\n")

	# Write decisions made to the file
	with open(decisions_made_path, 'w') as file:
		for decision in finalDecision_List:
			file.write(f"{decision}\n")

	# Write correct decisions to the file
	with open(correct_decisions_path, 'w') as file:
		for decision in correctDecision_List:
			file.write(f"{decision}\n")

	with open(full_decisions_path, 'w') as file:
		for decision in decision_records:
			file.write(f"{decision}\n")

	with open(full_Optimaldecisions_path, 'w') as file:
		for decision in optimalDecision_records:
			file.write(f"{decision}\n")

	# Write optimal decisions to the file
	with open(optimal_decisions_path, 'w') as file:
		for decision in optimalDecision_List:
			file.write(f"{decision}\n")

	# Write optimal decisions to the file
	with open(trajectories_path, 'w') as file:
		for decision in trajectories_List:
			file.write(f"{decision}\n")




def run_total_last_passage_practice(screen, screen_width, screen_height, clock, game_duration, qP, qM, pi0,  aid):


	if aid==1: 
		pygame.display.set_caption("Amendable Decisions Game")
		textDisplay = f"Amendable Decisions Game: Practice Round with Aid"
		show_initial_screen_practice(screen, screen_width, screen_height, textDisplay, 1)
	else:
		pygame.display.set_caption("Amendable Decisions Game")
		textDisplay = f"Amendable Decisions Game: Practice Round without Aid"
		show_initial_screen_practice(screen, screen_width, screen_height, textDisplay, 1)


	averageDecision = bestDecision = worseDecision = 0; 

	j=0

	pushQ = False 
	running = True

	while running:
        # Run a single game round
		pushQ = run_last_passage_game_practice(screen, clock, game_duration, qP, qM, pi0, j, averageDecision, bestDecision, worseDecision, aid)
		j += 1  # Increment the repetition count

		if pushQ:
			running = False

		# Check for quit events
		for event in pygame.event.get():
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_q:  # Check if 'q' was pressed
					running = False
			elif event.type == pygame.QUIT:
					running = False  # Allow quitt



def run_first_passage_game(screen, clock, finalDecision_List, finalDecisionTime_List, correctDecision_List, trajectories_List, qP,qM, pi0, gameNumber):
	screen_width, screen_height = screen.get_size()
	black = (0, 0, 0)
	white = (255, 255, 255)
	color_amend = (33, 158, 188)
	color_irr = (251, 133, 0)
	green = (34, 139, 34)  # Forest green
	red = (220, 20, 60)    # Crimson red


	cohBias = np.exp(pi0)/(1+np.exp(pi0))

	H = np.random.choice([-1, 1], p=[cohBias, 1-cohBias])

	if H==1:
		q = qP
	else: 
		q = qM

	correct_decision = (int)(H)
	correctDecision_List.append(correct_decision) 

	dot = {'x': screen_width/2, 'y': screen_height/2}

	start_time = pygame.time.get_ticks()

	running = True

	current_decision = 'None'

	trajectory = []

	while running:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				exit()
			elif event.type == pygame.KEYDOWN:
				if event.key == pygame.K_ESCAPE:
					screen_width, screen_height = 800, 600
					screen = pygame.display.set_mode((screen_width, screen_height))

		screen.fill(white)
		update_dot(dot, screen_width, q)
		draw_dot(screen, dot, black)  
		trajectory.append((dot['x'], dot['y']))

		decisionT, time = handle_user_input(pygame)
		if time is not None:
			current_decision = decisionT
			decision_time = time - start_time
			running = False

		draw_text(screen, f"Irrevocable decisions game", (50, 50), 30, color_irr)
		draw_text(screen, f"Number of games played: {gameNumber}", (50, 90), 30, black)
		pygame.display.flip()
		clock.tick(60)

	finalDecision_List.append(current_decision)
	finalDecisionTime_List.append(decision_time)
	trajectories_List.append(trajectory)

  # Ensure decision_times is not empty to avoid division by zero and other errors
	if len(finalDecisionTime_List):
		average_decision_time = round(sum(finalDecisionTime_List) / len(finalDecisionTime_List),0)
		worst_decision_time = max(finalDecisionTime_List)
		best_decision_time = min(finalDecisionTime_List)
	else:
		average_decision_time = 0
		worst_decision_time = 0
		best_decision_time = 0


	# Ensure decision_times is not empty to avoid division by zero and other errors
#	if decision_times:
#		average_decision_time = round(sum(decision_times) / len(decision_times),0)
#		worst_decision_time = max(decision_times)
#		best_decision_time = min(decision_times)
#	else:
#		average_decision_time = 0
#		worst_decision_time = 0
#		best_decision_time = 0


	if current_decision == correct_decision:
		message1 = f"Correct decision!"
		message2 = f"Final time: {decision_time}ms"
		show_end_message_practicev2(screen, message1, message2, green,  white, average_decision_time, best_decision_time)
	else: 
		message1 = f"Wrong decision! \n Please try to be more accurate"
		message2 = f"Final time: {decision_time}ms"
		show_end_message_practicev2(screen, message1, message2, red, white, average_decision_time, best_decision_time)


def run_total_first_passage(screen, screen_width, screen_height, clock, qP, qM, pi0, num_repetitions, game_ID, full_folder_path, game_counter):

	finalDecision_List = []
	finalDecisionTime_List = []
	correctDecision_List = []
	trajectories_List = []


	# Variables to track performance
	correct_games = 0
	total_decision_time = 0

	pygame.display.set_caption("Irrevocable decisions")
	textDisplay = f"Irrevocable Decisions Game {game_counter}"
	show_initial_screen(screen, screen_width, screen_height, textDisplay, -1)

	for j in range(num_repetitions):
		run_first_passage_game(screen, clock, finalDecision_List, finalDecisionTime_List, correctDecision_List, trajectories_List, qP,qM, pi0, j)


	#display_summary(screen, num_repetitions, fraction_correct, average_decision_time)

	# Define file paths
	decision_times_path = os.path.join(full_folder_path, f'{game_ID}_final_decision_times.txt')
	decisions_made_path = os.path.join(full_folder_path, f'{game_ID}_final_decisions.txt')
	correct_decisions_path = os.path.join(full_folder_path, f'{game_ID}_correct_decisions.txt')
	trajectories_path = os.path.join(full_folder_path, f'{game_ID}_trajectories.txt')

	# Write event times to the file
	with open(decision_times_path, 'w') as file:
		for finalD in finalDecisionTime_List:
        		file.write(f"{finalD}\n")
	
	# Write decisions made to the file
	with open(decisions_made_path, 'w') as file:
		for decision in finalDecision_List:
			file.write(f"{decision}\n")

	# Write correct decisions to the file
	with open(correct_decisions_path, 'w') as file:
		for decision in correctDecision_List:
			file.write(f"{decision}\n")


	# Write correct decisions to the file
	with open(trajectories_path, 'w') as file:
		for decision in trajectories_List:
			file.write(f"{decision}\n")




def run_first_passage_game_practice(screen, clock, qP, qM, pi0, gameNumber, averageDecisionTime, bestDecisionTime, worseDecisionTime, aid):

	screen_width, screen_height = screen.get_size()
	black = (0, 0, 0)
	white = (255, 255, 255)
	color_amend = (33, 158, 188)
	color_irr = (251, 133, 0)
	green = (34, 139, 34)  # Forest green
	red = (220, 20, 60)    # Crimson red


	cohBias = np.exp(pi0)/(1+np.exp(pi0))

	H = np.random.choice([-1, 1], p=[cohBias, 1-cohBias])

	if H==1:
		q = qP
	else: 
		q = qM

	correct_decision = (int)(H)

	dot = {'x': screen_width/2, 'y': screen_height/2}

	start_time = pygame.time.get_ticks()

	running = True
	pushQ = False 

	current_decision = 'None'

	while running:

		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				exit()
			elif event.type == pygame.KEYDOWN:
				if event.key == pygame.K_ESCAPE:
					screen_width, screen_height = 800, 600
					screen = pygame.display.set_mode((screen_width, screen_height))
				elif event.key == pygame.K_q:
					running = False
					pushQ = True
					return pushQ
					#pygame.quit()

		screen.fill(white)
		update_dot(dot, screen_width, q)
		draw_dot(screen, dot, black)  
		if aid == 1:
			draw_dashed_vertical_line(screen, black, thickness=2, dash_length=10, gap_length=10)


		decisionT, time = handle_user_input(pygame)
		if time is not None:
			current_decision = decisionT
			decision_time = time - start_time
			running = False

		if aid == 1:
			draw_text(screen, f"Irrevocable decisions game: with aid", (50, 50), 30, color_irr)
		else:
			draw_text(screen, f"Irrevocable decisions game: without aid", (50, 50), 30, color_irr)			
		draw_text(screen, f"Number of games played: {gameNumber}", (50, 90), 30, black)
		draw_text(screen, f"Push the q button to exit", (50, screen_height-50), 30, black)
		pygame.display.flip()
		clock.tick(60)


  # Ensure decision_times is not empty to avoid division by zero and other errors


	averageDecisionTime = (gameNumber*averageDecisionTime+decision_time)/(gameNumber+1)
	if decision_time<bestDecisionTime:
		bestDecisionTime=decision_time
	if decision_time>worseDecisionTime:
		worseDecisionTime = decision_time

	if current_decision == correct_decision:
		message1 = f"Correct decision!"
		message2 = f"Final time: {decision_time}ms"
		show_end_message_practicev2(screen, message1, message2, green,  white, averageDecisionTime, bestDecisionTime)
	else : 
		message1 = f"Wrong decision! \n Please try to be more accurate"
		message2 = f"Final time: {decision_time}ms"
		show_end_message_practicev2(screen, message1, message2, red, white, averageDecisionTime, bestDecisionTime)





def run_total_first_passage_practice(screen, screen_width, screen_height, clock, qP, qM, pi0,aid):

	if aid==1: 
		pygame.display.set_caption("Irrevocable Decisions Game")
		textDisplay = f"Irrevocable Decisions Game: Practice Round with Aid"
		show_initial_screen_practice(screen, screen_width, screen_height, textDisplay, 0)
	else:
		pygame.display.set_caption("Irrevocable Decisions Game")
		textDisplay = f"Irrevocable Decisions Game: Practice Round without Aid"
		show_initial_screen_practice(screen, screen_width, screen_height, textDisplay, 0)


	averageDecisionTime = bestDecisionTime = worseDecisionTime = 0;
	bestDecisionTime = 1000000000000 

	j=0

	pushQ = False 
	running = True

	while running:
        # Run a single game round
		pushQ = run_first_passage_game_practice(screen, clock, qP, qM, pi0, j, averageDecisionTime, bestDecisionTime, worseDecisionTime, aid)
		j += 1  # Increment the repetition count

		if pushQ:
			running = False

		# Check for quit events
		for event in pygame.event.get():
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_q:  # Check if 'q' was pressed
					running = False
			elif event.type == pygame.QUIT:
					running = False  # Allow quitt

