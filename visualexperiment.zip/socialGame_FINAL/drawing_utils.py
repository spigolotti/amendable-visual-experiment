import pygame
import sys

def draw_text(surface, text, position, font_size, color):
	font = pygame.font.Font(None, font_size)
	text_surface = font.render(text, True, color)
	surface.blit(text_surface, position)

def draw_dot(surface, dot, color):
	pygame.draw.circle(surface, color, (dot['x'], dot['y']), 10)

def draw_dashed_vertical_line(surface, color, thickness=2, dash_length=10, gap_length=10):
	# Get the dimensions of the surface
	surface_width, surface_height = surface.get_size()
    
	# Calculate the x position for the center line
	x_center = surface_width // 2
    
	# Draw dashes along the vertical center line
	y = 0
	while y < surface_height:
		# Draw a small line segment (dash)
		pygame.draw.line(surface, color, (x_center, y), (x_center, y + dash_length), thickness)
		y += dash_length + gap_length  # Move y down by dash + gap length for the next segment


def show_end_message(surface, message, color, background_color, average_time, worst_time, best_time, font_size=30):
	# Fill the background
	surface.fill(background_color)
    
	# Combine the message and stats into multiple lines
	stats_message = f"{message}\nAverage Time: {average_time}ms\nWorst Time: {worst_time}ms\nBest Time: {best_time}ms"
    
	# Define font and calculate the total height of the text block
	font = pygame.font.Font(None, font_size)
	lines = stats_message.split('\n')
	text_height = len(lines) * font_size

	# Get the center position for each line
	surface_width, surface_height = surface.get_size()
	y_offset = (surface_height - text_height) // 2  # Starting y position for centering
    
	for offset, line in enumerate(lines):
		text_surface = font.render(line, True, color)
		text_rect = text_surface.get_rect(center=(surface_width // 2, y_offset + offset * font_size))
		surface.blit(text_surface, text_rect.topleft)

	pygame.display.flip()
	pygame.time.delay(2000)  # Display the message for 2 seconds


def show_end_message_practice(screen, message1, message2, color, background_color, averageDecisionTime, font_size=60, stats_font_size = 40):

	
	black = (0,0,0)

	# Fill the background
	screen.fill(background_color)
    
	# Define fonts
	large_font = pygame.font.Font(None, font_size)          # Font for message1
	small_font = pygame.font.Font(None, stats_font_size)    # Font for message2 and stats

    # Create lines for the messages
	lines = [
		(message1, large_font, color),                      # message1 in larger font and specified color
		(message2, small_font, black),                      # message2 in smaller font and black
		(f"Average Time: {averageDecisionTime}ms", small_font, black)  # Stats in smaller font and black
	]

	# Calculate total height for centered positioning
	total_text_height = sum(font.size(line[0])[1] for line, font, _ in lines)
	screen_width, screen_height = screen.get_size()
	y_offset = (screen_height - total_text_height) // 2


	for message, font, line_color in lines:

		sub_lines = message.split('\n')

		# Render each line of the message
		for sub_line in sub_lines:
			text_surface = font.render(sub_line, True, line_color)
			text_rect = text_surface.get_rect(center=(screen_width // 2, y_offset))
			screen.blit(text_surface, text_rect.topleft)
			y_offset += font.size(sub_line)[1]  

	# Render each line, centered horizontally
	#for line, font, line_color in lines:
#		text_surface = font.render(line, True, line_color)#
	#	text_rect = text_surface.get_rect(center=(screen_width // 2, y_offset))
#		screen.blit(text_surface, text_rect.topleft)#
#		y_offset += font.size(line)[1]  # Move y_offset down by the height of the current line

	# Update the display and add a delay
	pygame.display.flip()
	pygame.time.delay(2000)  # Display the message for 2 seconds



def show_end_message_practicev2(screen, message1, message2, color, background_color, averageDecisionTime, bestDecisionTime, font_size=60, stats_font_size = 40):

	
	black = (0,0,0)

	# Fill the background
	screen.fill(background_color)
    
	# Define fonts
	large_font = pygame.font.Font(None, font_size)          # Font for message1
	small_font = pygame.font.Font(None, stats_font_size)    # Font for message2 and stats

    # Create lines for the messages
	lines = [
		(message1, large_font, color),                      # message1 in larger font and specified color
		(message2, small_font, black),                      # message2 in smaller font and black
		(f"Average Time: {averageDecisionTime}ms", small_font, black),  # Stats in smaller font and black
		(f"Best Time: {bestDecisionTime}ms", small_font, black)  # Stats in smaller font and black
	]

	# Calculate total height for centered positioning
	total_text_height = sum(font.size(line[0])[1] for line, font, _ in lines)
	screen_width, screen_height = screen.get_size()
	y_offset = (screen_height - total_text_height) // 2

	# Render each line, centered horizontally
	for message, font, line_color in lines:

		sub_lines = message.split('\n')

        	# Render each line of the message
		for sub_line in sub_lines:
			text_surface = font.render(sub_line, True, line_color)
			text_rect = text_surface.get_rect(center=(screen_width // 2, y_offset))
			screen.blit(text_surface, text_rect.topleft)
			y_offset += font.size(sub_line)[1]  

		#text_surface = font.render(line, True, line_color)
		#text_rect = text_surface.get_rect(center=(screen_width // 2, y_offset))
		#screen.blit(text_surface, text_rect.topleft)
		#y_offset += font.size(line)[1]  # Move y_offset down by the height of the current line

	# Update the display and add a delay
	pygame.display.flip()
	pygame.time.delay(2000)  # Display the message for 2 seconds



	# Fill the background
#	surface.fill(background_color)
    
	# Combine the message and stats into multiple lines
#	stats_message = f"{message}\nAverage Time: {average_time}ms"
    
	# Define font and calculate the total height of the text block
#	font = pygame.font.Font(None, font_size)
#	lines = stats_message.split('\n')
#	text_height = len(lines) * font_size
#
	# Get the center position for each line
#	surface_width, surface_height = surface.get_size()
#	y_offset = (surface_height - text_height) // 2  # Starting y position for centering
 #   
#	for offset, line in enumerate(lines):
#		text_surface = font.render(line, True, color)
#		text_rect = text_surface.get_rect(center=(surface_width // 2, y_offset + offset * font_size))
#		surface.blit(text_surface, text_rect.topleft)

#	pygame.display.flip()
#	pygame.time.delay(2000)  # Display the message for 2 seconds




#def show_end_message(surface, message, color, background_color, average_time, worst_time, best_time, font_size=30, position=(50, 100)):
#	surface.fill(background_color)
#	stats_message = f"{message}\nAverage Time: {average_time}ms"
	# Splitting the message to display it on multiple lines
#	for offset, line in enumerate(stats_message.split('\n')):
#		draw_text(surface, line, (position[0], position[1] + offset * 30), font_size, color)
#	pygame.display.flip()
#	pygame.time.delay(2000)  # Display the message for 5 seconds


def show_initial_screen(screen, screen_width, screen_height, text, gametype):

	black = (0, 0, 0)
	white = (255, 255, 255)
	color_amend = (33, 158, 188)
	color_irr = (251, 133, 0)

	screen.fill(black)  # Fill the screen with black
	font = pygame.font.SysFont('arial', 48)  # Use a readable font
	#   text_surface = font.render("Reversible Decision Game", True, (255, 255, 255))  # Render the text in white
	if gametype==1:
		clr=color_amend
	else:
		clr=color_irr
	main_text_surface = font.render(text, True, clr)  # Render the text in the right color
	main_text_rect = main_text_surface.get_rect(center=(screen_width / 2, screen_height / 2 - 70))
	screen.blit(main_text_surface, main_text_rect)  # Draw the text onto the screen
	pygame.display.flip()  # Update the display to show the text

	# Create the flickering message
	prompt_font = pygame.font.SysFont('arial', 32)  # Smaller font for the prompt
	prompt_text = "Take a short break, then push Y to continue"
	prompt_surface = prompt_font.render(prompt_text, True, (255, 255, 255))
	prompt_rect = prompt_surface.get_rect(center=(screen_width / 2, screen_height / 2 + 70))

	prompt_visible = True  # Initially, the prompt is visible
	last_toggle_time = pygame.time.get_ticks()
	toggle_interval = 500  # Interval in milliseconds to toggle visibility

	while True:
		current_time = pygame.time.get_ticks()
		if current_time - last_toggle_time > toggle_interval:
			prompt_visible = not prompt_visible  # Toggle the visibility
			last_toggle_time = current_time  # Reset the toggle timer
        
		screen.fill((0, 0, 0))  # Clear the screen
		screen.blit(main_text_surface, main_text_rect)  # Redraw the main text

		if prompt_visible:
			screen.blit(prompt_surface, prompt_rect)  # Draw the prompt text only if it's visible
        
		pygame.display.flip()  # Update the display

		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == pygame.KEYDOWN:
				if event.key == pygame.K_y:  # Check if the spacebar is pressed
					return  # Exit the function when spacebar is pressed
				elif event.key == pygame.K_ESCAPE:
					pygame.quit()
					sys.exit()



def show_initial_screen_practice(screen, screen_width, screen_height, text, gametype):

	black = (0, 0, 0)
	white = (255, 255, 255)
	color_amend = (33, 158, 188)
	color_irr = (251, 133, 0)

	screen.fill(black)  # Fill the screen with black
	font = pygame.font.SysFont('arial', 48)  # Use a readable font
	#   text_surface = font.render("Reversible Decision Game", True, (255, 255, 255))  # Render the text in white
	if gametype==1:
		clr=color_amend
	else:
		clr=color_irr
	main_text_surface = font.render(text, True, clr)  # Render the text in the right color
	main_text_rect = main_text_surface.get_rect(center=(screen_width / 2, screen_height / 2 - 70))
	screen.blit(main_text_surface, main_text_rect)  # Draw the text onto the screen
	pygame.display.flip()  # Update the display to show the text

	# Create the flickering message
	prompt_font = pygame.font.SysFont('arial', 32)  # Smaller font for the prompt
	prompt_text = "push Y to continue"
	prompt_surface = prompt_font.render(prompt_text, True, (255, 255, 255))
	prompt_rect = prompt_surface.get_rect(center=(screen_width / 2, screen_height / 2 + 70))

	prompt_visible = True  # Initially, the prompt is visible
	last_toggle_time = pygame.time.get_ticks()
	toggle_interval = 500  # Interval in milliseconds to toggle visibility

	while True:
		current_time = pygame.time.get_ticks()
		if current_time - last_toggle_time > toggle_interval:
			prompt_visible = not prompt_visible  # Toggle the visibility
			last_toggle_time = current_time  # Reset the toggle timer
        
		screen.fill((0, 0, 0))  # Clear the screen
		screen.blit(main_text_surface, main_text_rect)  # Redraw the main text

		if prompt_visible:
			screen.blit(prompt_surface, prompt_rect)  # Draw the prompt text only if it's visible
        
		pygame.display.flip()  # Update the display

		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == pygame.KEYDOWN:
				if event.key == pygame.K_y:  # Check if the spacebar is pressed
					return  # Exit the function when spacebar is pressed
				elif event.key == pygame.K_ESCAPE:
					pygame.quit()
					sys.exit()
