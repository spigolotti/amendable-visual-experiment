import csv
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import sys
import numpy as np
from scipy.optimize import curve_fit

#def model_func(n, q, norm):
#    """Model function with tau as a parameter."""
#    return np.power(q*(1-q),n/2)


def read_decision_times(csv_file_path):
    """Reads decision times from a given CSV file."""
    decision_times = []
    with open(csv_file_path, newline='') as file:
        reader = csv.reader(file)
        next(reader)  # Skip the header
        for row in reader:
            try:
                decision_times.append(float(row[0]))  # Assuming the first column is decision times
            except ValueError:
                # Handle the case where conversion to float fails
                print(f"Skipping invalid row: {row}")
    return decision_times



def main():
	if len(sys.argv) != 2:
		print("Usage: python generate_histogram.py <path_to_csv_file 1> ")
		sys.exit(1)

	csv_file_path_1 = sys.argv[1]
#	csv_file_path_2 = sys.argv[2]
	pdf_file_path = "data/decision_times_histogram.pdf"

	decision_times_1 = read_decision_times(csv_file_path_1)
	meanTime = np.sum(decision_times_1)/100.
	print(meanTime)
	print(2768)
#	decision_times_2 = read_decision_times(csv_file_path_2)

	hist_1, bin_edges_1 = np.histogram(decision_times_1, bins=10, density=True)
	bin_centers_1 = (bin_edges_1[:-1] + bin_edges_1[1:]) / 2.  # Calculate bin centers

	#hist_2, bin_edges_2 = np.histogram(decision_times_2, bins=10, density=True)
	#bin_centers_2 = (bin_edges_2[:-1] + bin_edges_2[1:]) / 2.  # Calculate bin centers

	# Curve fitting
	# popt contains the optimal parameters (in this case, just tau)
	#popt, pcov = curve_fit(model_func, bin_centers_1, hist_1, p0=[1])

	# Extracting the estimated tau
#	tau_estimated = popt[0]

	# Plotting the histogram
	plt.hist(decision_times_1, bins=10, density=True, alpha=0.6, label='Last passage')
#	plt.hist(decision_times_2, bins=10, density=True, alpha=0.6, label='First passage')

	# Plotting the fitted function
#	t_values = np.linspace(start=1, stop=max(decision_times_1), num=500)#
#	fitted_values = model_func(t_values, tau_estimated)#
#	print(tau_estimated)
#	plt.plot(t_values, fitted_values, label='Fitted last passage', color='red')

	plt.xlabel('Decision Time (ms)')
	plt.ylabel('Density')
	plt.legend()
	plt.ylim([0,0.0005])

	with PdfPages(pdf_file_path) as pdf:
		pdf.savefig()
		plt.close()



if __name__ == "__main__":
    main()
